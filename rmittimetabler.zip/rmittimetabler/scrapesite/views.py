from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.shortcuts import render
from .forms import NameForm
from .WebScraping import *
import sys
from subprocess import run, PIPE

def home(request):
    return render(request, "home.html")

def user(request):
    if request.method == 'POST':
        form = NameForm(request.POST)
        if form.is_valid():
            userin = form.cleaned_data["username"]
            passin = form.cleaned_data["password"]

            # For production:
            time, info, color = scrapefunction(userin, passin)

            # For development:
            # time = ['Mon14:302 hrs', 'Wed10:302 hrs', 'Fri10:302 hrs', 'Mon17:302 hrs', 'Thu12:302 hrs', 'Fri14:302 hrs', 'Wed12:302 hrs', 'Mon09:302 hrs', 'Tue13:302 hrs', 'Wed12:302 hrs', 'Mon10:302 hrs', 'Fri13:301 hr', 'Wed11:301 hr', 'Tue10:301 hr', 'Tue13:301 hr', 'Fri14:301 hr', 'Mon14:301 hr', 'Thu14:301 hr', 'Wed16:301 hr', 'Wed14:301 hr', 'Thu14:301 hr', 'Fri14:301 hr', 'Thu16:301 hr', 'Tue09:301 hr', 'Mon16:301 hr', 'Tue16:301 hr', 'Wed15:301 hr', 'Mon16:301 hr', 'Fri11:301 hr', 'Wed14:302 hrs', 'Wed16:301 hr', 'Mon11:301 hr', 'Wed10:301 hr', 'Wed12:301 hr', 'Wed13:301 hr', 'Thu13:301 hr', 'Thu14:301 hr', 'Fri12:301 hr', 'Thu18:301 hr', 'Mon17:301 hr', 'Thu17:301 hr', 'Fri10:301 hr', 'Fri12:301 hr', 'Thu12:301 hr', 'Tue12:301 hr', 'Thu12:301 hr', 'Mon16:301 hr', 'Wed11:301 hr', 'Thu13:301 hr', 'Tue16:301 hr', 'Fri13:301 hr', 'Wed10:301 hr', 'Tue17:301 hr', 'Mon18:301 hr', 'Wed16:301 hr', 'Thu09:301 hr', 'Thu12:301 hr', 'Fri09:301 hr', 'Wed11:301 hr', 'Mon12:301 hr', 'Wed17:302 hrs', 'Tue17:302 hrs', 'Wed15:302 hrs', 'Tue15:302 hrs', 'Wed15:302 hrs', 'Thu18:302 hrs', 'Tue12:302 hrs', 'Wed09:302 hrs', 'Wed11:302 hrs', 'Thu10:302 hrs', 'Thu12:302 hrs']
            # info = [['Programming 1', 'LEC', '080.04.006'], ['Programming 1', 'PRA', '014.10.031'], ['Programming 1', 'PRA', '014.09.023'], ['Programming 1', 'PRA', '056.04.087'], ['Programming 1', 'PRA', '014.10.031'], ['Programming 1', 'PRA', '056.04.082'], ['Programming 1', 'PRA', '014.10.031'], ['Programming 1', 'PRA', '014.10.030'], ['Programming 1', 'PRA', '014.10.031'], ['Data Comm & Net-centric Comp', 'LEC', '080.02.002'], ['Data Comm & Net-centric Comp', 'LEC', '080.04.006'], ['Data Comm & Net-centric Comp', 'TUT', '057.03.010'], ['Data Comm & Net-centric Comp', 'TUT', '070.03.004'], ['Data Comm & Net-centric Comp', 'TUT', '056.07.091'], ['Data Comm & Net-centric Comp', 'TUT', '080.09.008'], ['Data Comm & Net-centric Comp', 'TUT', '057.03.010'], ['Data Comm & Net-centric Comp', 'TUT', '014.06.019'], ['Data Comm & Net-centric Comp', 'TUT', '056.03.089'], ['Data Comm & Net-centric Comp', 'TUT', '014.06.013'], ['Data Comm & Net-centric Comp', 'TUT', '014.06.019'], ['Data Comm & Net-centric Comp', 'TUT', '057.03.010'], ['Data Comm & Net-centric Comp', 'TUT', '012.10.034'], ['Data Comm & Net-centric Comp', 'TUT', '013.03.012'], ['Data Comm & Net-centric Comp', 'TUT', '013.04.009'], ['Data Comm & Net-centric Comp', 'TUT', '080.09.008'], ['Data Comm & Net-centric Comp', 'TUT', '013.03.005'], ['Data Comm & Net-centric Comp', 'TUT', '056.06.085'], ['Data Comm & Net-centric Comp', 'TUT', '013.03.012'], ['Data Comm & Net-centric Comp', 'TUT', '013.03.012'], ['Web Programming', 'LEC', '080.02.007'], ['Web Programming', 'PRA', '014.10.030'], ['Web Programming', 'PRA', '014.10.031'], ['Web Programming', 'PRA', '056.04.088'], ['Web Programming', 'PRA', '056.04.088'], ['Web Programming', 'PRA', '056.04.082'], ['Web Programming', 'PRA', '056.04.084'], ['Web Programming', 'PRA', '056.04.084'], ['Web Programming', 'PRA', '056.04.084'], ['Web Programming', 'PRA', '014.10.031'], ['Web Programming', 'PRA', '014.10.031'], ['Web Programming', 'PRA', '014.10.030'], ['Web Programming', 'PRA', '010.08.020'], ['Web Programming', 'TUT', '010.13.018'], ['Web Programming', 'TUT', '056.07.093'], ['Web Programming', 'TUT', '056.07.093'], ['Web Programming', 'TUT', '056.03.095'], ['Web Programming', 'TUT', '057.03.010'], ['Web Programming', 'TUT', '057.03.010'], ['Web Programming', 'TUT', '056.03.095'], ['Web Programming', 'TUT', '056.07.093'], ['Web Programming', 'TUT', '010.13.018'], ['Web Programming', 'TUT', '056.03.089'], ['Web Programming', 'TUT', '080.03.011'], ['Web Programming', 'TUT', '080.04.020'], ['Web Programming', 'TUT', '080.08.010'], ['Web Programming', 'TUT', '056.03.089'], ['Web Programming', 'TUT', '013.04.009'], ['Web Programming', 'TUT', '013.03.012'], ['Web Programming', 'TUT', '008.08.044'], ['Web Programming', 'TUT', '010.08.026'], ['Building IT Systems', 'LEC', '080.04.006'], ['Building IT Systems', 'TUT', '014.06.019'], ['Building IT Systems', 'TUT', '013.03.011'], ['Building IT Systems', 'TUT', '008.08.045'], ['Building IT Systems', 'TUT', '014.06.016'], ['Building IT Systems', 'TUT', '014.06.016'], ['Building IT Systems', 'TUT', '014.06.016'], ['Building IT Systems', 'TUT', '056.05.094'], ['Building IT Systems', 'TUT', '056.05.094'], ['Building IT Systems', 'TUT', '056.05.094'], ['Building IT Systems', 'TUT', '056.05.094']]
            # color = ['newcourse', 'Programming 1', 'Programming 1LEC', 'Programming 1PRA', 'newcourse', 'Data Comm & Net-centric Comp', 'Data Comm & Net-centric CompLEC', 'Data Comm & Net-centric CompTUT', 'newcourse', 'Web Programming', 'Web ProgrammingLEC', 'Web ProgrammingPRA', 'Web ProgrammingTUT', 'newcourse', 'Building IT Systems', 'Building IT SystemsLEC', 'Building IT SystemsTUT']

            data = zip(time, info)
            colorsorted = []
            palette = ['255, 128, 128', '255, 179, 179', '179, 89, 89', '128, 255, 128', '179, 255, 179', '89, 179, 89', '128, 128, 255', '179, 179, 255', '89, 89, 179', '255, 128, 255', '255, 179, 255', '179, 89, 179', '255, 210, 128', '255, 228, 179', '179, 147, 89']

            def sortbylength(s):
                return s[0][3:8]

            data = sorted(data, key=sortbylength)

            j = 0
            for c in color:
                if color[j] == 'newcourse':
                    del color[j+1]
                j +=1

            j = 0
            color.append('end')
            color.append('end')
            color.append('end')
            while j < len(color):
                if color[j] == 'end':
                    break
                if color[j] == 'newcourse':
                    colorsorted.append(color[j+1])
                    if color[j+2] == 'newcourse':
                        colorsorted.append('none')
                        colorsorted.append('none')
                    else:
                        colorsorted.append(color[j+2])
                        if color[j+3] == 'newcourse':
                            colorsorted.append('none')
                        else:
                            colorsorted.append(color[j+3])
                j += 1

            bg = {k: v for k, v in zip(colorsorted, palette)}
            colorcode = []
            code = []
            for cp in list(bg):
                if cp != 'none' and cp != 'end':
                    colorcode.append('<div class="colorcode"><div class="color" style="background-color: rgba(' + bg[cp] + ');"></div>' + '<span class="colortext" onclick="hideOtherClasses(this)">' + cp[:-3] + ' ' + cp[-3:] + '</span>' + '</div>')
                    code.append('<div class="code" style="display: none;">' + bg[cp] + '</div>')

            xdict = {'Mon': 97, 'Tue': 300, 'Wed': 503, 'Thu': 706, 'Fri': 909}
            ydict = {'06:00': 36, '06:30': 71, '07:00': 106, '07:30': 141, '08:00': 176, '08:30': 211, '09:00': 246, '09:30': 281, '10:00': 316, '10:30': 351, '11:00': 386, '11:30': 421, '12:00': 456, '12:30': 491, '13:00': 526, '13:30': 561, '14:00': 596, '14:30': 631, '15:00': 666, '15:30': 701, '16:00': 736, '16:30': 771, '17:00': 806, '17:30': 841, '18:00': 876, '18:30': 911, '19:00': 946, '19:30': 981, '20:00': 1016, '20:30': 1051, '21:00': 1086, '21:30': 1121}
            xshift = {}
            divs = []
            height = 59
            gradient = 0.7
            name = 0

            for t, i in data:

                if '2 hrs' in t:
                    height = 129
                    gradient = 0.5
                else:
                    height = 59
                    gradient = 0.7

                if t[0:8] not in xshift:
                    xshift[t[0:8]] = 0

                divs.append('<div onclick="raise(this)" class="cell" style="left: ' + str(xdict[t[0:3]]+xshift[t[0:8]]) + 'px; top: ' + str(ydict[t[3:8]]) + 'px; ' + 'height: ' + str(height) + 'px; ' + 'background: linear-gradient(0deg, rgba(' + bg[i[0]+i[1]] + ',' + str(gradient) + ') 0%, rgba(' + bg[i[0]+i[1]] + ',' + '1) 50%);' + '">' + '<div class="celltext">' + i[0] + '<br>' + i[1] + '<br>' + i[2] + '</div>' + '</div>')
                xshift[t[0:8]] = xshift[t[0:8]]+26

            return render(request, 'user.html', {'divs': divs, 'colorcode': colorcode, 'code': code})

        else:
            return render(request, "home.html")

def main(request):
    return render(request, "main.html")