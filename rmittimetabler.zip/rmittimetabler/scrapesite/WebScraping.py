#!/bin/env python3

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options as ChromeOptions
from textwrap import shorten
from django.http import HttpResponse
import os

def scrapefunction(userin, passin):

    # For production:
    CHROMEDRIVER_PATH = "/app/.chromedriver/bin/chromedriver"
    chrome_bin = os.environ.get('GOOGLE_CHROME_BIN', "chromedriver")
    options = ChromeOptions()
    options.binary_location = chrome_bin
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument('headless')
    options.add_argument('window-size=1200x600')
    driver = webdriver.Chrome(executable_path=CHROMEDRIVER_PATH, chrome_options=options)
    url = "https://sso-cas.rmit.edu.au/rmitcas/login?service=https://mytimetable.rmit.edu.au/even/student"
    driver.get(url)

    # For development:
    # options = webdriver.ChromeOptions()
    # options.add_argument('headless')
    # driver = webdriver.Chrome(executable_path='C:\\Users\\Will\\AppData\\Local\\Programs\\Python\\Python37-32\\chromedriver\\chromedriver.exe', chrome_options=options)
    # driver.set_window_size(1366,768)
    # driver.set_window_position(0,0)
    # url = "https://sso-cas.rmit.edu.au/rmitcas/login?service=https://mytimetable.rmit.edu.au/even/student"
    # driver.get(url)

    username = driver.find_element_by_id("username")
    password = driver.find_element_by_id("password")

    username.send_keys(userin)
    password.send_keys(passin)

    driver.find_element_by_name("submit").click()

    html = driver.page_source
    soup = BeautifulSoup(html, "html.parser")

    links = []
    for a in soup.find_all('a', href=True):
        a = a['href']
        if "#group/" in a:
            a = ("https://sso-cas.rmit.edu.au/rmitcas/login?service=https://mytimetable.rmit.edu.au/even/student" + a)
            links.append(a)

    raw = []
    color = []
    currentlink = 0
    i = 0

    while currentlink < len(links):
        driver.get(links[currentlink])
        wait = WebDriverWait(driver, 10)
        wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'aplus-table')))
        html = driver.page_source
        soup = BeautifulSoup(html, "html.parser")
        course = soup.find('div', attrs={'class': 'desc-text'})
        course.h3.decompose()
        course = course.get_text()
        junk, course, group = course.split('\n\t\t')
        group = shorten(group, width=3, placeholder='')
        for cell in soup.find_all('td'):
            cell = cell.get_text()
            if "\n\n" != cell and "" != cell:
                if i != 0 and i != 3 and i != 4 and i != 7:
                    if i == 1:
                        raw.append(course)
                        raw.append(group)
                        if course not in color:
                            color.append('newcourse')
                            color.append(course)
                        if course + group not in color:
                            color.append(course + group)
                    raw.append(cell)
                    i += 1
                else:
                    i += 1
            if i == 8:
                i = 0
        currentlink += 1

    driver.close()

    w, h = 3, int((len(raw)/3)/2)
    info = [[0 for x in range(w)] for y in range(h)]
    time = []

    i = 0
    j = 0
    k = 0

    while i < len(raw):
        time.append(raw[i+2]+raw[i+3]+raw[i+5])
        info[k][j] = raw[i]
        info[k][j+1] = raw[i+1]
        info[k][j+2] = raw[i+4]
        i += 6
        k += 1

    return time, info, color