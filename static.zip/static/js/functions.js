function hideOtherClasses(col) {
    var col = col.innerHTML;
    var regex = /(<br>)/gi;
    var cells = document.getElementsByClassName('cell'), i;
    for (i = 0; i < cells.length; i += 1) {
        var cell = cells[i].innerHTML.replace(regex, ' ');
        if ((cell).includes(col)) {
            cells[i].style.display = '';
        }
        else {
            cells[i].style.display = 'none';
        }
    }
    preferences('singleClasses');
}

function raise(div) {
    if (div.className.match(/(?:^|\s)cell(?!\S)/)) {
        div.className = "cellraised";
    }
    else {
        div.className = "cell";
    }
}

function hide() {
    var cells = document.getElementsByClassName('cell'), i;
    for (i = 0; i < cells.length; i += 1) {
        cells[i].style.display = 'none';
    }
}

function show() {
    var cells = document.getElementsByClassName('cell'), i;
    for (i = 0; i < cells.length; i += 1) {
        cells[i].style.display = '';
    }
}

function finish() {
    hide();
    var cells = document.getElementsByClassName("cellraised"), i;
    for (var i = cells.length-1; i >= 0; i--) {
        var x = cells[i].getBoundingClientRect();
        if (x.left >= 97 && x.left < 300) {
            cells[i].style.left = "97px";
        }
        else if (x.left >= 300 && x.left < 503) {
            cells[i].style.left = "300px";
        }
        else if (x.left >= 503 && x.left < 706) {
            cells[i].style.left = "503px";
        }
        else if (x.left >= 706 && x.left < 909) {
            cells[i].style.left = "706px";
        }
        else {
            cells[i].style.left = "909px";
        }
    }

    var cells = document.getElementsByClassName("cellraised"), i;
    for(var i = cells.length-1; i >= 0; i--) {
        cells[i].className = 'cellfinish';
    }

    var code = document.getElementsByClassName("code"), i;
    var k = 0;
    for(var i = code.length-1; i >= 0; i--) {
        var cells = document.getElementsByClassName("cellfinish"), j;
        for(var j = cells.length-1; j >= 0; j--) {
            if ((cells[j].style.background).includes(code[i].innerHTML)) {
                k++;
                j = 0;
            }
        }
    }
    if (k < code.length) {
        var screen = document.getElementById("screennormal");
        var popup = document.getElementById("popupnone");
        screen.id = "screenpopup";
        popup.id = "popup";
    }
}

function closePopup() {
    var screen = document.getElementById("screenpopup");
    var popup = document.getElementById("popup");
    screen.id = "screennormal";
    popup.id = "popupnone";
}

var pressed = 0;
function walkTime() {
    pressed++;
    var button1 = document.getElementById("walktime1");
    var button2 = document.getElementById("walktime2");
    var message = document.getElementById("walktimemessage");
    if (pressed == 2) {
        var cells = document.getElementsByClassName("cellraised"), i;
        var regex1 = /\d{3}/;
        var regex2 = /^0+/;
        a = cells[0].innerHTML;
        b = cells[1].innerHTML;
        a = regex1.exec(a);
        b = regex1.exec(b);
        a = a[0].replace(regex2, '');
        b = b[0].replace(regex2, '');
        var googlemaps = "https://www.google.com/maps/dir/RMIT+Building+" + a + "/RMIT+Building+" + b;
        window.open(googlemaps);
        for(var i = cells.length-1; i >= 0; i--) {
            cells[i].className = 'cell';
        }
        button1.style.display = "";
        button2.style.display = "none";
        message.style.display = "none";
        pressed = 0;
    }
    else {
        button1.style.display = "none";
        button2.style.display = "inline-block";
        message.style.display = "inline-block";
    }
}

function download() {
    domtoimage.toBlob(document.getElementById('download'))
        .then(function(blob) {
            window.saveAs(blob, 'RMIT-timetable.png');
        });
}

var userdays = "";
function preferences(type) {
    var cells = document.getElementsByClassName("cell");
    if (type == 'reset') {
        for (var i = cells.length-1; i >= 0; i--) {
            cells[i].style.display = '';
        }
        userdays = "";
    }
    else {
        var userday = document.getElementById('preferencesday').value;
        userdays += userday;
        var userbefore = document.getElementById('preferencesbefore').value;
        var userafter = document.getElementById('preferencesafter').value;
        var before = document.getElementsByClassName("timeheader")[userbefore].getBoundingClientRect();
        var after = document.getElementsByClassName("timeheader")[userafter].getBoundingClientRect();
        if (type !== "singleClasses") {
            for (var i = cells.length-1; i >= 0; i--) {
                cells[i].style.display = '';
            }
        }
        for (var i = cells.length-1; i >= 0; i--) {
            var x = cells[i].getBoundingClientRect();
            if (x.left >= 97 && x.left < 300 && userdays.includes("Mon")) {
                cells[i].style.display = 'none';
            }
            else if (x.left >= 300 && x.left < 503 && userdays.includes("Tue")) {
                cells[i].style.display = 'none';
            }
            else if (x.left >= 503 && x.left < 706 && userdays.includes("Wed")) {
                cells[i].style.display = 'none';
            }
            else if (x.left >= 706 && x.left < 909 && userdays.includes("Thu")) {
                cells[i].style.display = 'none';
            }
            else if (x.left >= 909 && userdays.includes("Fri")) {
                cells[i].style.display = 'none';
            }
        }
        for (var i = cells.length-1; i >= 0; i--) {
            var cell = cells[i].getBoundingClientRect();
            if (cell.top < before.top) {
                cells[i].style.display = 'none';
            }
            if (cell.top > after.top) {
                cells[i].style.display = 'none';
            }
        }
    }
}
